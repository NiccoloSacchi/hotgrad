# -*- coding: utf-8 -*-
""" Definition of the exceptions. """

class BackwardException(Exception):
    pass