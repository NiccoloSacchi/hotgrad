# A deep learning framework
This project implements a deep learning framework using only pytorch Tensors.

Folders and files:
    - hotgrad: our deep learning framework
    - dataset_generator.py: generates a simple dataset
    - test.py: test a neural network on the dataset and shows the accurancy
    - report.pdf: contains the report

More details in the Report.
